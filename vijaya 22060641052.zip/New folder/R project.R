#descriptive Statistics
library(readxl)
Cars4912 <- read_excel("Cars4912.xlsx")
View(Cars4912)
attach(Cars4912)
summary(Cars4912)
str(Cars4912)
correlation<-cor(Cars4912[,4:8])
correlation
#Here we check linearity
plot(`Fuel Tank Capacity`~Height,data=Cars4912)
plot(`Fuel Tank Capacity`~Length,data=Cars4912)
#we can fit data in multiple regression 
data1=data.frame(`Fuel Tank Capacity`,Length,Height)
data1
plot(data1)
multiple.regression=lm(`Fuel Tank Capacity`~Height+Length,data=data1)
summary(multiple.regression)
##Interpretation
#1)p value<0.05 so we reject H0
#2)Here Adjusted R-squared value is 0.6742.Therefore 67.42% variation in Fuel tank capacity and independent variable (Height, Length)
##Residuals analysis
et=residuals(multiple.regression)
et
plot(fitted(multiple.regression),et)
abline(0,0)
#create Q-Q plot for residuals
qqnorm(et)
#Add a straight diagonal line to the plot
qqline(et)
#Create density plot of residuals
plot(density(et))
#density plot roughly follows a bell shape,which ensures that the residuals are slightly normally distributed.





